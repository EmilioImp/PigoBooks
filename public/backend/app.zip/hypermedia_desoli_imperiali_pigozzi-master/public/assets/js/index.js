$(document).ready(function () {

    if (window.sessionStorage.getItem("lastPage")) window.sessionStorage.removeItem("lastPage");
    if (window.sessionStorage.getItem("penultimePage")) window.sessionStorage.removeItem("penultimePage");

});